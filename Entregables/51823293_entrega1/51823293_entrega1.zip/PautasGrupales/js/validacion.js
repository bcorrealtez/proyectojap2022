/*Miembros del grupo:
            Santiago Buero
            Jonhattan Ferreti
            Nicolas Papazian
            Bruno Correa
*/

const sAlerta=document.getElementById("alert-success");
const dAlerta=document.getElementById("alert-danger");

function showAlertSuccess() {
    sAlerta.classList.add("show","arribalerta");
}

function showAlertError() {
    dAlerta.classList.add("show");
}

const nom=document.querySelector('#nombre');
const ape=document.querySelector('#apellido');
const mail=document.querySelector('#email');
const pass1=document.querySelector('#password1');
const pass2=document.querySelector('#password2');
const check=document.querySelector('#terminos');
const btn=document.querySelector('#regBtn');

const sClose=sAlerta.querySelector('.btn-close');
const dClose=dAlerta.querySelector('.btn-close');

btn.addEventListener('click', ()=>{
    if (nom.value=='' || ape.value=='' || mail.value=='' || pass1.value=='' || pass2.value!==pass1.value || pass1.value.length<6 || !check.checked) {
        showAlertError();
    } else {
        showAlertSuccess(); 
    }
});


sClose.addEventListener('click', ()=>{
    sAlerta.classList.remove("show","arribalerta");
});

dClose.addEventListener('click', ()=>{
    dAlerta.classList.remove("show");
});